import os
from typing import TypedDict, List
from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage

# ---------- 初始化模型 ----------
llm = ChatOpenAI(model="gpt-4o", temperature=0.7, openai_api_key=os.getenv("OPENAI_API_KEY"))

# ---------- 状态定义 ----------
class WriterState(TypedDict):
    topic: str               # 初始选题
    research_brief: str      # 分析师输出（摘要）
    outline: str             # 架构师输出（大纲）
    draft: str               # 写手输出（正文）
    final: str               # 主编输出（终稿）
    token_usage: dict        # token 消耗统计
    search_cache: dict       # 搜索缓存 (query -> result)

# ---------- 模拟搜索工具（带缓存） ----------
def search_tool(query: str, state: WriterState) -> str:
    # 先从缓存中查找
    if query in state["search_cache"]:
        print(f"   [缓存命中] {query}")
        return state["search_cache"][query]

    # 模拟外部搜索（实际可接入 SerpAPI 等）
    print(f"   [真实搜索] {query}")
    result = f"关于'{query}'的最新数据：... (此处为搜索结果摘要)"
    state["search_cache"][query] = result
    return result

# ---------- 上下文摘要压缩（避免全量历史传递） ----------
def compress_context(state: WriterState, for_agent: str) -> str:
    """根据下游 Agent 需求，只传递必要摘要，大幅减少 token"""
    if for_agent == "analyst":
        return f"需要分析的选题：{state['topic']}"
    elif for_agent == "architect":
        return f"选题：{state['topic']}\n研究摘要：{state['research_brief']}"
    elif for_agent == "writer":
        return f"大纲：{state['outline']}\n关键事实（来自搜索）：..."
    elif for_agent == "editor":
        return f"初稿：{state['draft'][:3000]}...\n品牌要求：专业、数据驱动、无冗余"
    return ""

# ---------- 四个 Agent 节点 ----------
def analyst_node(state: WriterState) -> WriterState:
    """分析师：抓取动态 + 数据摘要"""
    # 搜索行业趋势（带缓存）
    trend = search_tool(f"{state['topic']} 2025 趋势", state)
    data = search_tool(f"{state['topic']} 市场规模 2025", state)

    prompt = f"{compress_context(state, 'analyst')}\n搜索结果：{trend}\n{data}\n请生成200字以内的研究简报。"
    response = llm.invoke([HumanMessage(content=prompt)])
    state["research_brief"] = response.content
    _update_token(state, response)
    return state

def architect_node(state: WriterState) -> WriterState:
    """架构师：生成含论点链的大纲"""
    prompt = f"{compress_context(state, 'architect')}\n请生成一份包含3个核心论点及支撑数据的大纲。"
    response = llm.invoke([HumanMessage(content=prompt)])
    state["outline"] = response.content
    _update_token(state, response)
    return state

def writer_node(state: WriterState) -> WriterState:
    """写手：逐节生成正文，并调用搜索核实事实"""
    # 为每一节调用搜索进行事实核查（示例只核查第一个论点）
    outline_lines = state["outline"].split("\n")
    fact_query = outline_lines[0] if outline_lines else state["topic"]
    fact_check = search_tool(f"核实: {fact_query}", state)

    prompt = f"{compress_context(state, 'writer')}\n额外核实信息：{fact_check}\n请根据大纲撰写1000字正文，每个数据后标注来源。"
    response = llm.invoke([HumanMessage(content=prompt)])
    state["draft"] = response.content
    _update_token(state, response)
    return state

def editor_node(state: WriterState) -> WriterState:
    """主编：语法、合规、风格审核"""
    prompt = f"{compress_context(state, 'editor')}\n请进行风格统一、事实复核、语法修正，直接输出终稿。"
    response = llm.invoke([HumanMessage(content=prompt)])
    state["final"] = response.content
    _update_token(state, response)
    return state

def _update_token(state: WriterState, response):
    """累计 token 消耗（用于优化证明）"""
    usage = response.response_metadata.get("token_usage", {})
    for k, v in usage.items():
        state["token_usage"][k] = state["token_usage"].get(k, 0) + v

# ---------- 构建 LangGraph 工作流 ----------
builder = StateGraph(WriterState)

builder.add_node("分析师", analyst_node)
builder.add_node("架构师", architect_node)
builder.add_node("写手", writer_node)
builder.add_node("主编", editor_node)

builder.set_entry_point("分析师")
builder.add_edge("分析师", "架构师")
builder.add_edge("架构师", "写手")
builder.add_edge("写手", "主编")
builder.add_edge("主编", END)

graph = builder.compile()

# ---------- 运行示例 ----------
if __name__ == "__main__":
    initial_state: WriterState = {
        "topic": "2025年全球AI Agent市场规模与竞争格局",
        "research_brief": "",
        "outline": "",
        "draft": "",
        "final": "",
        "token_usage": {"prompt_tokens": 0, "completion_tokens": 0},
        "search_cache": {}
    }
    final_state = graph.invoke(initial_state)

    print("======== 终稿 ========")
    print(final_state["final"][:500])
    print("\n======== Token 消耗 ========")
    print(final_state["token_usage"])